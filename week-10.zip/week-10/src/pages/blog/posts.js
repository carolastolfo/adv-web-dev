export default function Posts(){
    return(
        <div>
            <header>This is where my blog posts go.</header>
        </div>
    )
}