export default function About(){
    return (
        <div>This is the about page</div>
    )
}