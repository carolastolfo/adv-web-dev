export default function Projects(){
    return (
        <h1>Projects</h1>
    )
}