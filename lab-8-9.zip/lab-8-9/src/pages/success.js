export default function Success(){
    return (
        <div>
            <h1>Your authentication was successful!</h1>
        </div>
    )
}